#ifndef CBJ_TIMPWM
#define CBJ_TIMPWM
#ifdef __cplusplus
extern "C"{
#endif // __cplusplus
	void tim4_init(unsigned short autoreload, unsigned short prescaler);
	void tim3_init(unsigned short autoreload, unsigned short prescaler);
	unsigned long long tim3_gettime_us();
#ifdef __cplusplus
}
#endif // __cplusplus

#endif // !CBJ_TIMPWM
