#ifndef CBJ_STM32H7_OLED
#define CBJ_STM32H7_OLED
#include "common.h"
#include "oledfont.h"
#define OLED_IIC_ADDR 0x3c
#define SIZE 8
#define XLevelL		0x00
#define XLevelH		0x10
#define Max_Column	128
#define Max_Row		64
#define	Brightness	0xFF 
#define X_WIDTH 	128
#define Y_WIDTH 	64	
#ifdef __cplusplus
extern "C"{
#endif // __cplusplus
	typedef struct _oled{
		char mode;//0:iic 1:spi
		union _hardeare{
			struct _iic{
				char iicindex;
				char addr;
			}iic;
			struct _spi{
				char spiindex;
				void(*reset)(char value);
				void(*dc)(char value);
				void(*cs)(char value);
				void(*initpins)();
			}spi;
		}hardware;
	}oled;
	void oled_writebyte(oled *p, char ch, char isdata);
	void oled_clear(oled *p, char fill);
	void oled_setpos(oled *p, char x, char y);
	void oled_setdisp(oled *p, char ison);
	void oled_showchar(oled *p, char x, char y, char ch, char chsiz);
	void oled_showstr(oled *p, char x, char y, char *str, char chsiz);
	void oled_drawpic(oled *p, char x0, char y0, char x1, char y1, char *img);
	void oled_init(oled *p);
	void oled_reset(oled *p);

	//hardware pins for oled1@spi1
	void oled1_spi1_dc(char value);
	void oled1_spi1_cs(char value);
	void oled1_spi1_reset(char value);
	void oled1_spi1_hwinit();

#ifdef __cplusplus
}
#endif // __cplusplus

#endif // !CBJ_STM32H7_OLED
