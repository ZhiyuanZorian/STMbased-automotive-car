#include "common.h"
#include "delay.h"
#include "oled.h"
#include "iicspi.h"
extern I2C_HandleTypeDef hiicx[2];
extern SPI_HandleTypeDef hspix[2];
//oled_spi1
void oled1_spi1_dc(char value){
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_2, value);
}
void oled1_spi1_cs(char value){
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_3, value);
}
void oled1_spi1_reset(char value){
	HAL_GPIO_WritePin(GPIOA, GPIO_PIN_1, value);
}
void oled1_spi1_hwinit(){
	GPIO_InitTypeDef gpio;
	gpio.Pin = GPIO_PIN_3 | GPIO_PIN_2 | GPIO_PIN_1;
	gpio.Mode = GPIO_MODE_OUTPUT_PP;
	gpio.Speed = GPIO_SPEED_FREQ_HIGH;
	HAL_GPIO_Init(GPIOA, &gpio);
}

//shared functions
void oled_writebyte(oled *p, char ch, char isdata){
	char res = 0;
	if(p->mode){//spi
		(p->hardware.spi.dc)(isdata);
		(p->hardware.spi.cs)(0);
		HAL_SPI_Transmit(hspix + (p->hardware.spi.spiindex), &ch, 1, 1000);
		(p->hardware.spi.cs)(1);
	}
	else{
		//char buf[2] = { isdata ? 0x40 : 0x00,ch };
		char buf[2]={0};buf[1]=ch;buf[0]=isdata?0x40:0x00;
		HAL_I2C_Master_Transmit(hiicx + (p->hardware.iic.iicindex), p->hardware.iic.addr << 1, buf, 2, 1000);

	}
}
void oled_clear(oled *p, char fill){
	char m, n;
	for(m = 0; m < 8; m++){
		oled_writebyte(p, 0xb0 + m, 0);
		oled_writebyte(p, 0x00, 0);
		oled_writebyte(p, 0x10, 0);
		for(n = 0; n < 128; n++){
			oled_writebyte(p, fill, 1);
		}
	}
}
void oled_reset(oled *p){
	//spi only
	if(p->mode){
		(p->hardware.spi.reset)(0);
		delay_us(50);
		(p->hardware.spi.reset)(1);
		oled_init(p);
	}
	
}
void oled_setpos(oled *p, char x, char y){
	oled_writebyte(p, 0xb0 + y, 0);
	oled_writebyte(p, ((x & 0xf0) >> 4) | 0x10, 0);
	oled_writebyte(p, (x & 0x0f), 0);
}
void oled_setdisp(oled *p, char ison){
	oled_writebyte(p, 0x8d, 0);
	oled_writebyte(p, ison ? 0x14 : 0x10, 0);
	oled_writebyte(p, ison ? 0xaf : 0xae, 0);
}
void oled_showchar(oled *p, char x, char y, char ch, char chsiz){
	char c = ch - ' ', i = 0;
	if(x >= Max_Column){
		x = 0; y += 2;
	}
	if(chsiz == 16){
		oled_setpos(p, x, y);
		for(i = 0; i < 8; i++){
			oled_writebyte(p, F8X16[c * 16 + i], 1);
		}
		oled_setpos(p, x, y + 1);
		for(i = 0; i < 8; i++){
			oled_writebyte(p, F8X16[c * 16 + i + 8], 1);
		}
	}
	else if(chsiz == 8){
		oled_setpos(p, x, y);
		for(i = 0; i < 6; i++){
			oled_writebyte(p, F6x8[c][i], 1);
		}
	}
}
void oled_showstr(oled *p, char x, char y, char *str, char chsiz){
	char j = 0;
	while(str[j]){
		oled_showchar(p, x, y, str[j], chsiz);
		x += 8;
		if(x > 120){
			x = 0; y += 2;
		}
		j++;
	}
}
void oled_drawpic(oled *p, char x0, char y0, char x1, char y1, char *img){
	int j = 0;
	char x, y;
	if(y1 % 8 == 0){
		y = y1 / 8;
	}
	else{
		y = y1 / 8 + 1;
	}
	for(y = y0; y < y1; y++){
		oled_setpos(p, x0, y);
		for(x = x0; x < x1; x++){
			oled_writebyte(p, img[j++], 1);
		}
	}
}
void oled_init(oled *p){
	if(p->mode){
		(p->hardware.spi.initpins)();
		(p->hardware.spi.reset)(1);
	}
	oled_writebyte(p, 0xae, 0);//disp off
	oled_writebyte(p, 0x00, 0);//set low column addr
	oled_writebyte(p, 0x10, 0);//set high column addr
	oled_writebyte(p, 0x40, 0);//set start line addr
	oled_writebyte(p, 0xb0, 0);//set page addr
	oled_writebyte(p, 0x81, 0);//contract control
	oled_writebyte(p, 0xff, 0);//128
	oled_writebyte(p, 0xa1, 0);//set segment remap
	oled_writebyte(p, 0xa6, 0);//normal or reverse
	oled_writebyte(p, 0xa8, 0);//multiplex ratio 1 to 64
	oled_writebyte(p, 0x3f, 0);// 1/32 duty
	oled_writebyte(p, 0xc8, 0);//com scan dir
	oled_writebyte(p, 0xd3, 0);//display offset
	oled_writebyte(p, 0x00, 0);//
	oled_writebyte(p, 0xd5, 0);//osc. div.
	oled_writebyte(p, 0x80, 0);
	oled_writebyte(p, 0xd8, 0);//area color mode off
	oled_writebyte(p, 0x05, 0);
	oled_writebyte(p, 0xd9, 0);//pre-charge period
	oled_writebyte(p, 0xf1, 0);
	oled_writebyte(p, 0xda, 0);//com pin config
	oled_writebyte(p, 0x12, 0);
	oled_writebyte(p, 0xdb, 0);//vcomh
	oled_writebyte(p, 0x30, 0);
	oled_writebyte(p, 0x8d, 0);//charge pump enable
	oled_writebyte(p, 0x14, 0);
	oled_writebyte(p, 0xaf, 0);//turn on oled panel
	oled_clear(p, 0);
}