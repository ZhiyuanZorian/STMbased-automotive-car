#ifndef CBJ_F103DELAY
#define CBJ_F103DELAY
#ifdef __cplusplus
extern "C"{
#endif // __cplusplus
	void delay_init(unsigned int sysclk);
	void delay_us(unsigned int nus);
	void delay_ms(unsigned short nms);
#ifdef __cplusplus
}
#endif // __cplusplus
#endif // !CBJ_F103DELAY

