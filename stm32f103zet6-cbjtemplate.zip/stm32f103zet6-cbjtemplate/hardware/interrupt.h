#ifndef CBJ_INTERRUPT
#define CBJ_INTERRUPT
#ifdef __cplusplus
extern "C"{
#endif
#include "common.h"
    void hcsr04_initall();
    void hcsr04_pulse(char group);
    float hcsr04_distance(char group);
#ifdef __cplusplus
}
#endif    
#endif