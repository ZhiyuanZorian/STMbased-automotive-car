#include "timpwm.h"
#include "common.h"
#include "usart.h"
#include "car.h"
TIM_HandleTypeDef htim5, htim4, htim3;
extern uartbuf uartrecv[3];
volatile unsigned int time_1s = 0, time_1ms = 0;
volatile unsigned char counter_1ms = 0, counter_5ms = 0;
volatile signed char speed_count = 0;
void tim4_init(unsigned short autoreload, unsigned short prescaler){
	htim4.Instance = TIM4;
	htim4.Init.Prescaler = prescaler;
	htim4.Init.CounterMode = TIM_COUNTERMODE_UP;
	htim4.Init.Period = autoreload;
	htim4.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
	HAL_TIM_Base_Init(&htim4);
	HAL_TIM_Base_Start_IT(&htim4);
}
void tim3_init(unsigned short autoreload, unsigned short prescaler){
	htim3.Instance = TIM3;
	htim3.Init.Prescaler = prescaler;
	htim3.Init.CounterMode = TIM_COUNTERMODE_UP;
	htim3.Init.Period = autoreload;
	htim3.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
	HAL_TIM_Base_Init(&htim3);
	HAL_NVIC_SetPriority(TIM3_IRQn, 1, 3);
	HAL_NVIC_EnableIRQ(TIM3_IRQn);
	HAL_TIM_Base_Start_IT(&htim3);
}
void tim5_init_counter(){
	htim5.Instance = TIM5;
	htim5.Init.CounterMode = TIM_COUNTERMODE_DOWN;
	htim5.Init.Prescaler = 71;
	htim5.Init.Period = 65535;
	htim5.Init.ClockDivision = TIM_CLOCKDIVISION_DIV1;
	HAL_TIM_Base_Init(&htim5);
}
void HAL_TIM_Base_MspInit(TIM_HandleTypeDef *phtim){
	switch((unsigned int)phtim->Instance){
	case TIM3_BASE:
		__HAL_RCC_TIM3_CLK_ENABLE();		
		break;
	case TIM4_BASE:
		__HAL_RCC_TIM4_CLK_ENABLE();
		HAL_NVIC_SetPriority(TIM4_IRQn, 1, 3);
		HAL_NVIC_EnableIRQ(TIM4_IRQn);
		break;
	case TIM5_BASE:
		__HAL_RCC_TIM5_CLK_ENABLE();
		break;
	default:
		break;
	}
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *phtim){
	switch((int)(phtim->Instance)){
	case TIM3_BASE:		
		time_1ms++;
		counter_1ms++;
		speed_count++;
		if(counter_1ms >= 5){
			counter_1ms = 0;
			counter_5ms++;
		}
		if(speed_count >= 50){
			speed_count = 0;
		}
		car_move_1ms();
		if(time_1ms >= 1000){
			time_1ms = 0;
			time_1s++;
			HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_13);
			//uart_senddata(0, "cbj1\r\n", 6);
		}
		
		//uart_senddata(0, "cbj1\r\n", 6);
		break;
	case TIM4_BASE:
		uart_senddata(0, "timer4 period elasped interrupt!\r\n", 34);
		break;
	default:
		break;
	}
}
unsigned long long tim3_gettime_us(){
	return (unsigned long long)((time_1s * 1000000llu + time_1ms * 1000llu) + TIM3->CNT);
}
void TIM3_IRQHandler(){//timing since start
	HAL_TIM_IRQHandler(&htim3);
}
void TIM4_IRQHandler(){//for wifi@uart3
#if UART3_WIFI == 1
	uartrecv[2].flag |= (1 << 15);
	__HAL_TIM_CLEAR_FLAG(&htim4, TIM_EVENTSOURCE_UPDATE);
	TIM4->CR1 &= (~1);
#else
	HAL_TIM_IRQHandler(&htim4);
#endif
}
