#ifndef CBJ_F103USART
#define CBJ_F103USART
#ifdef __cplusplus
extern "C"{
#endif // __cplusplus
#define UART3_WIFI 1
	typedef struct _uartbuf{
		char *buffer;
		int flag;
		int length;
	}uartbuf;
	void uart1_init(int baudrate);
	void uart3_init(int baudrate);
	void uart_sendchar(char index, char data);
	void uart_senddata(char index, char *data, int len);
	void uart_sendcrlf(char index);
	int uart_readdata(char index, char *buffer, int maxnum);
#ifdef __cplusplus
}
#endif // __cplusplus

#endif // !CBJ_F103USART

