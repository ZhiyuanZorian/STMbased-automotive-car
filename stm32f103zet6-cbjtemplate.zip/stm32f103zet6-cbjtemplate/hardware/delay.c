#include "common.h"
#include "delay.h"
static unsigned int fac_us = 0;
void SysTick_Handler(void){
	HAL_IncTick();
	//HAL_SYSTICK_IRQHandler();
}
void delay_init(unsigned int sysclk){
	HAL_SYSTICK_CLKSourceConfig(SYSTICK_CLKSOURCE_HCLK);
	fac_us = sysclk;
	//NVIC_DisableIRQ(SysTick_IRQn);
}
void delay_us(unsigned int nus){
	unsigned int ticks, told, tnow, tcnt = 0;
	ticks = nus * fac_us;
	told = SysTick->VAL;
	for(;;){
		tnow = SysTick->VAL;
		if(tnow != told){
			if(tnow < told)tcnt += told - tnow;
			else tcnt += ((SysTick->LOAD) - tnow + told);
			told = tnow;
			if(tcnt >= ticks)break;
		}
	}
}
void delay_ms(unsigned short nms){
	unsigned short i;
	for(i = 0;i < nms;i++){
		delay_us(1000);
	}
}