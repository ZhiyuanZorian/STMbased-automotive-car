#include "common.h"
#include "delay.h"
#include "usart.h"
#include "timpwm.h"
UART_HandleTypeDef huartx[3] = { 0 };
uartbuf uartrecv[3] = { 0 };
unsigned char recv[3];
char debugbuffer[256] = { 0 };
char wifibuffer[1024] = { 0 };
extern TIM_HandleTypeDef htim4;
void uartx_wifihandler(char index, TIM_TypeDef *timx);
void uart_sendchar(char index, char data){
	HAL_UART_Transmit(huartx + index, &data, 1, 1000);
	while(__HAL_UART_GET_FLAG(huartx + index, UART_FLAG_TC) != SET);//wait until send complete
}
void uart_senddata(char index, char *data, int len){
	HAL_UART_Transmit(huartx + index, data, len, 1000);
	while(__HAL_UART_GET_FLAG(huartx + index, UART_FLAG_TC) != SET);
}
void uart_sendcrlf(char index){
	HAL_UART_Transmit(huartx + index, "\r\n", 2, 1000);
	while(__HAL_UART_GET_FLAG(huartx + index, UART_FLAG_TC) != SET);
}
int uart_readdata(char index, char *buffer, int maxnum){
	int len = uartrecv[index].flag & 0x3fff;
	memcpy(buffer, uartrecv[index].buffer, len > maxnum ? maxnum : len);
	uartrecv[index].flag = 0;
	return len;
}
void uart1_init(int baudrate){
	uartrecv[0].buffer = debugbuffer;
	uartrecv[0].length = 256;
	huartx[0].Instance = USART1;
	huartx[0].Init.BaudRate = baudrate;
	huartx[0].Init.WordLength = UART_WORDLENGTH_8B;
	huartx[0].Init.StopBits = UART_STOPBITS_1;
	huartx[0].Init.Parity = UART_PARITY_NONE;
	huartx[0].Init.HwFlowCtl = UART_HWCONTROL_NONE;
	huartx[0].Init.Mode = UART_MODE_TX_RX;
	HAL_UART_Init(huartx);
	HAL_UART_Receive_IT(huartx, recv, 1);
}
void uart3_init(int baudrate){
	uartrecv[2].buffer = wifibuffer;
	uartrecv[2].length = 1024;
	huartx[2].Instance = USART3;
	huartx[2].Init.BaudRate = baudrate;
	huartx[2].Init.WordLength = UART_WORDLENGTH_8B;
	huartx[2].Init.StopBits = UART_STOPBITS_1;
	huartx[2].Init.Parity = UART_PARITY_NONE;
	huartx[2].Init.HwFlowCtl = UART_HWCONTROL_NONE;
	huartx[2].Init.Mode = UART_MODE_TX_RX;
	HAL_UART_Init(huartx + 2);
#if UART3_WIFI == 1
	tim4_init(1000 - 1, 9000 - 1);
	uartrecv[2].flag = 0;
	__HAL_UART_ENABLE_IT(huartx + 2, USART_IT_RXNE);
#else
	HAL_UART_Receive_IT(huartx + 2, recv + 2, 1);
#endif
}
void HAL_UART_MspInit(UART_HandleTypeDef *phuart){
	GPIO_InitTypeDef gpio;
	if(phuart->Instance == USART1){
		__HAL_RCC_USART1_CLK_ENABLE();
		gpio.Pin = GPIO_PIN_9;
		gpio.Mode = GPIO_MODE_AF_PP;
		gpio.Pull = GPIO_PULLUP;
		gpio.Speed = GPIO_SPEED_FREQ_HIGH;
		HAL_GPIO_Init(GPIOA, &gpio);
		gpio.Pin = GPIO_PIN_10;
		gpio.Mode = GPIO_MODE_AF_INPUT;
		HAL_GPIO_Init(GPIOA, &gpio);
		HAL_NVIC_EnableIRQ(USART1_IRQn);
		HAL_NVIC_SetPriority(USART1_IRQn, 3, 1);
	}
	else if(phuart->Instance == USART3){
		//uart3 wifi TX:B10 RX:B11
		__HAL_RCC_USART3_CLK_ENABLE();
		gpio.Pin = GPIO_PIN_10;
		gpio.Mode = GPIO_MODE_AF_PP;
		gpio.Pull = GPIO_PULLUP;
		gpio.Speed = GPIO_SPEED_FREQ_HIGH;
		HAL_GPIO_Init(GPIOB, &gpio);
		gpio.Pin = GPIO_PIN_11;
		gpio.Mode = GPIO_MODE_AF_INPUT;
		HAL_GPIO_Init(GPIOB, &gpio);
		HAL_NVIC_EnableIRQ(USART3_IRQn);
		HAL_NVIC_SetPriority(USART3_IRQn, 3, 2);
	}
}
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart){
	char ind = 0;
	if(huart->Instance == USART3){
		ind = 2;
	}
	if(!(uartrecv[ind].flag & 0x8000)){//received LF (completed)
		if(uartrecv[ind].flag & 0x4000){//received CR
			if(recv[ind] != '\n')uartrecv[ind].flag = 0;
			else uartrecv[ind].flag |= 0x8000;
		}
		else{
			if(recv[ind] == '\r'){
				uartrecv[ind].flag |= 0x4000;
			}
			else{
				uartrecv[ind].buffer[uartrecv[ind].flag & 0x3fff] = recv[ind];
				uartrecv[ind].flag++;
				if(uartrecv[ind].flag > uartrecv[ind].length - 1)uartrecv[ind].flag = 0;
			}
		}
	}
}
void USART1_IRQHandler(){
	int timeout = 0, maxdelay = 0x1ffff;
	HAL_UART_IRQHandler(huartx);
	while(HAL_UART_GetState(huartx) != HAL_UART_STATE_READY){
		timeout++;
		if(timeout > maxdelay)break;
	}
	timeout = 0;
	while(HAL_UART_Receive_IT(huartx, recv, 1)){
		timeout++;
		if(timeout > maxdelay)break;
	}
}
void USART3_IRQHandler(){
#if UART3_WIFI==1
	uartx_wifihandler(2, TIM4);
#else
	int timeout = 0, maxdelay = 0x1ffff;
	HAL_UART_IRQHandler(huartx + 2);
	while(HAL_UART_GetState(huartx + 2) != HAL_UART_STATE_READY){
		timeout++;
		if(timeout > maxdelay)break;
	}
	timeout = 0;
	while(HAL_UART_Receive_IT(huartx, recv + 2, 1)){
		timeout++;
		if(timeout > maxdelay)break;
	}
#endif // UART3_WIFI
}
void uartx_wifihandler(char index, TIM_TypeDef *timx){
	unsigned char res;
	USART_TypeDef *uartx = huartx[index].Instance;
	if(__HAL_UART_GET_FLAG(huartx + index, UART_FLAG_RXNE)){
		//received data
		res = uartx->DR;
		if(!(uartrecv[index].flag & (1 << 15))){//received data not handled, do not accept other data
			if(uartrecv[index].flag < uartrecv[index].length - 1){
				timx->CNT = 0;//reset counter
				if(uartrecv[index].flag == 0){
					timx->CR1 |= 1;//open counter
				}
				uartrecv[index].buffer[uartrecv[index].flag++] = res;//receive
			}
			else{
				uartrecv[index].flag |= (1 << 15);//recv finish
			}
		}
	}
}