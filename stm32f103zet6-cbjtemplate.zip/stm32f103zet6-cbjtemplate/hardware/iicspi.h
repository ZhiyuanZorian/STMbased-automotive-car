#ifndef CBJ_F103HWIIC
#define CBJ_F103HWIIC
#ifdef __cplusplus
extern "C"{
#endif // __cplusplus
#include "common.h"
	//iic
	void iic1_init();
	void iic_scan(char index);
	char iic_readbyte(char index, char addr, char reg);
	void iic_writebyte(char index, char addr, char reg, char data);
	short iic_read16(char index, char addr, char reg, char bigendian);
	void iic_write16(char index, char addr, char reg, short data, char bigendian);
	//spi
	void spi1_init();
	void spi2_init();
	void spi_setspeed(char index, unsigned int spiprescaler);
	char spi_readwritebyte(char index, char data);
	void spi_transfer_interrupt(char index, char *sendbuffer, char *recvbuffer, unsigned int length);
	void spi_send_interrupt(char index, char *sendbuffer, unsigned int length);
	void spi_recv_interrupt(char index, char *recvbuffer, unsigned int length);
#ifdef __cplusplus
}
#endif // __cplusplus
#endif // !CBJ_F103HWIIC
