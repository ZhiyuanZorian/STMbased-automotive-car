#ifndef CBJ_CARHARDWARE
#define CBJ_CARHARDWARE
#ifdef __cplusplus
extern "C"{
#endif
#define SPEED_DUTY 50
#define COMM_STOP  'e'//stop
#define COMM_UP    'a'//forward
#define COMM_DOWN  'b'//backward
#define COMM_LEFT  'c'//turn left
#define COMM_RIGHT 'd'//turn right
#define COMM_UP2    'f'//forward slower
#include "common.h"
    typedef enum _direction{
        STOP=0,
        FORWARD = 1,
        BACKWARD = 2
    }movedirection;
    typedef enum _blackline{
        WWW = 0,
        WWB = 1,
        WBW = 2,
        WBB = 3,
        BWW = 4,
        BWB = 5,
        BBW = 6,
        BBB = 7
    }blacklinestatus;
    void car_forward();
    void car_forward_fast();
    void car_forward_slow();
    void car_backward();
    void car_left();
    void car_right();
    void car_stop();
    void motor_init();
    void motor_frontleft(movedirection dir);
    void motor_frontright(movedirection dir);
    void motor_backleft(movedirection dir);
    void motor_backright(movedirection dir);
    void car_move_1ms();
    void sensorinput_init();
    blacklinestatus readblackline();
    char leftobstacle();
    char rightobstacle();
    char envbrightness();
    void speedmeasure_clear();
    void speedmeasure();
#ifdef __cplusplus
}
#endif
#endif //CBJ_CARHARDWARE