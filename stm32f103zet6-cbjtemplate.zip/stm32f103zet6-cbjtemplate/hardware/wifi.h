#ifndef CBJ_WIFI_ESP8266DRIVER
#define CBJ_WIFI_ESP8266DRIVER
#ifdef __cplusplus
extern "C"{
#endif // __cplusplus
#define WIFI_UARTINDEX 2
#define WIFI_SENDBACK 0
	extern const char *wifista_ip;
	extern const char *wifista_port;
	//STA mode tcp/udp config
	void wifi_sendback_response(char mode);
	char *wifi_checkcmd(char *str);
	char wifi_apstacheck();
	char wifi_send(char *data, char *ack, unsigned short waittime, char newline);
	char wifi_quittrans();
	char wifi_constacheck();
	void wifi_getwanip(char *ipbuf);
	void wifi_initsta();
	void wifi_enter_passthrough(char *ip, char *port);
	void wifi_httpget(char *ip, char *port, char *url, char *query);
	void wifi_httppost(char *ip, char *port, char *url, char *query, char *form, unsigned int formlength);
	void processresponse1();
#ifdef __cplusplus
}
#endif // __cplusplus
#endif // !CBJ_WIFI_ESP8266DRIVER