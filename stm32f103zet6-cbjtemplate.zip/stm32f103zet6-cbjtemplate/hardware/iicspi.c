#include "iicspi.h"
#include "usart.h"
I2C_HandleTypeDef hiicx[2];
SPI_HandleTypeDef hspix[2];
volatile char spirx[2] = { 0 }, spitx[2] = { 0 }, spirxtx[2] = { 0 };
#pragma region hardware_iic
void iic1_init(){
	hiicx[0].Instance = I2C1;
	hiicx[0].Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
	hiicx[0].Init.ClockSpeed = 400000;
	hiicx[0].Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
	hiicx[0].Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
	hiicx[0].Init.OwnAddress1 = 0;
	hiicx[0].Init.OwnAddress2 = 0;
	hiicx[0].Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
	hiicx[0].Init.DutyCycle = I2C_DUTYCYCLE_2;
	if(HAL_I2C_Init(hiicx))for(;;);
}
void HAL_I2C_MspInit(I2C_HandleTypeDef *hiic){
	GPIO_InitTypeDef gpio;
	//B6:SCL B7:SDA
	if(hiic->Instance == I2C1){
		__HAL_RCC_I2C1_CLK_ENABLE();
		gpio.Pin = GPIO_PIN_6 | GPIO_PIN_7;
		gpio.Mode = GPIO_MODE_AF_OD;
		gpio.Pull = GPIO_NOPULL;
		gpio.Speed = GPIO_SPEED_FREQ_HIGH;
		HAL_GPIO_Init(GPIOB, &gpio);
	}
}
char reserved_addr(char addr){
	return (addr & 0x78) == 0 || (addr & 0x78) == 0x78;
}
void iic_scan(char index){
	char i;
	uart_senddata(0, "IIC SCAN\r\n", 11);
	uart_senddata(0, "    0  1  2  3  4  5  6  7  8  9  A  B  C  D  E  F\r\n", 53);
	for(i = 0;i < 0x80;i++){
		if(i % 16 == 0){
			uart_sendchar(0, i / 16 + '0');
			uart_sendchar(0, '0');
		}
		if(reserved_addr(i)){
			uart_sendchar(0, ' ');
			uart_sendchar(0, ' ');
			uart_sendchar(0, '.');
			continue;
		}
		else{
			uart_sendchar(0, ' ');
			uart_sendchar(0, ' ');
			if(HAL_I2C_Master_Transmit(hiicx + index, (i << 1), 0, 1, 100)){
				uart_sendchar(0, '.');
			}
			else{
				uart_sendchar(0, 'X');
			}
		}
		if(i % 16 == 15){
			uart_sendcrlf(0);
		}
	}
	uart_sendcrlf(0);
}
char iic_readbyte(char index, char addr, char reg){
	char result;
	HAL_I2C_Master_Transmit(hiicx + index, addr << 1, &reg, 1, 1000);
	HAL_I2C_Master_Receive(hiicx + index, addr << 1, &result, 1, 1000);
	return result;
}
void iic_writebyte(char index, char addr, char reg, char data){
	char buf[2] = { 0 };
	buf[0] = reg;
	buf[1] = data;
	HAL_I2C_Master_Transmit(hiicx + index, addr << 1, buf, 2, 1000);
}
short iic_read16(char index, char addr, char reg, char bigendian){
	char result[2] = { 0 };
	short x = 0;
	HAL_I2C_Master_Transmit(hiicx + index, addr << 1, &reg, 1, 1000);
	HAL_I2C_Master_Receive(hiicx + index, addr << 1, result, 2, 1000);
	if(bigendian){
		x = (result[0] << 8) | result[1];
	}
	else{
		x = (result[1] << 8) | result[0];
	}
	return x;
}
void iic_write16(char index, char addr, char reg, short data, char bigendian){
	char buf[3] = { 0 };
	buf[0]=reg;
	if(bigendian){
		buf[1] = ((data >> 8) & 0xff);
		buf[2] = (data & 0xff);
	}
	else{
		buf[2] = ((data >> 8) & 0xff);
		buf[1] = (data & 0xff);
	}
	HAL_I2C_Master_Transmit(hiicx + index, addr << 1, buf, 3, 1000);
}
#pragma endregion
#pragma region hardware_spi
char spi_readwritebyte(char index, char data){//poll
	char rx;
	HAL_SPI_TransmitReceive(hspix + index, &data, &rx, 1, 1000);
	return rx;
}
void spi_transfer_interrupt(char index, char *sendbuffer, char *recvbuffer, unsigned int length){
	spirxtx[index] = 0;
	if(HAL_SPI_TransmitReceive_IT(hspix + index, sendbuffer, recvbuffer, length)){
		for(;;);//spi error
	}
	while(!spirxtx[index]);//wait until transfer complete
}
void spi_send_interrupt(char index, char *sendbuffer, unsigned int length){
	spitx[index] = 0;
	if(HAL_SPI_Transmit_IT(hspix + index, sendbuffer, length)){
		for(;;);//spi error
	}
	while(!spitx[index]);//wait until transfer complete
}
void spi_recv_interrupt(char index, char *recvbuffer, unsigned int length){
	spirx[index] = 0;
	if(HAL_SPI_Receive_IT(hspix + index, recvbuffer, length)){
		for(;;);//spi error
	}
	while(!spirx[index]);//wait until transfer complete
}
void spi1_init(){
	/// <summary>
	/// spi1 poll for OLED
	/// </summary>
	hspix[0].Instance = SPI1;
	hspix[0].Init.Mode = SPI_MODE_MASTER;
	hspix[0].Init.Direction = SPI_DIRECTION_2LINES;
	hspix[0].Init.DataSize = SPI_DATASIZE_8BIT;
	hspix[0].Init.CLKPolarity = SPI_POLARITY_HIGH;
	hspix[0].Init.CLKPhase = SPI_PHASE_2EDGE;
	hspix[0].Init.NSS = SPI_NSS_SOFT;
	hspix[0].Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_8;
	hspix[0].Init.FirstBit = SPI_FIRSTBIT_MSB;
	hspix[0].Init.TIMode = SPI_TIMODE_DISABLE;
	hspix[0].Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
	hspix[0].Init.CRCPolynomial = 7;
	if(HAL_SPI_Init(hspix)){
		for(;;);
	}
	HAL_NVIC_SetPriority(SPI1_IRQn, 2, 1);
	HAL_NVIC_EnableIRQ(SPI1_IRQn);
}
void spi2_init(){
	/// <summary>
	/// spi2 interrupt for sdcard/w25qxx flash
	/// </summary>
	hspix[1].Instance = SPI2;
	hspix[1].Init.Mode = SPI_MODE_MASTER;
	hspix[1].Init.Direction = SPI_DIRECTION_2LINES;
	hspix[1].Init.DataSize = SPI_DATASIZE_8BIT;
	hspix[1].Init.CLKPolarity = SPI_POLARITY_HIGH;
	hspix[1].Init.CLKPhase = SPI_PHASE_2EDGE;
	hspix[1].Init.NSS = SPI_NSS_SOFT;
	hspix[1].Init.BaudRatePrescaler = SPI_BAUDRATEPRESCALER_32;
	hspix[1].Init.FirstBit = SPI_FIRSTBIT_MSB;
	hspix[1].Init.TIMode = SPI_TIMODE_DISABLE;
	hspix[1].Init.CRCCalculation = SPI_CRCCALCULATION_DISABLE;
	hspix[1].Init.CRCPolynomial = 7;
	if(HAL_SPI_Init(hspix + 1)){
		for(;;);
	}
	HAL_NVIC_SetPriority(SPI2_IRQn, 2, 2);
	HAL_NVIC_EnableIRQ(SPI2_IRQn);

}
void HAL_SPI_MspInit(SPI_HandleTypeDef *hspi){
	GPIO_InitTypeDef gpio;
	if(hspi->Instance == SPI1){
		__HAL_RCC_SPI1_CLK_ENABLE();
		//SCK:A5 MISO:A6 MOSI:A7
		gpio.Pin = GPIO_PIN_5 | GPIO_PIN_6 | GPIO_PIN_7;
		gpio.Mode = GPIO_MODE_AF_PP;
		gpio.Pull = GPIO_PULLUP;
		gpio.Speed = GPIO_SPEED_HIGH;
		HAL_GPIO_Init(GPIOA, &gpio);
	}
	else if(hspi->Instance == SPI2){
		//SCK: MISO: MOSI:
		//interrupt
		__HAL_RCC_SPI2_CLK_ENABLE();
		gpio.Pin = GPIO_PIN_13 | GPIO_PIN_14 | GPIO_PIN_15;
		gpio.Mode = GPIO_MODE_AF_PP;
		gpio.Pull = GPIO_PULLUP;
		gpio.Speed = GPIO_SPEED_HIGH;
		HAL_GPIO_Init(GPIOB, &gpio);
	}
}
void SPI1_IRQHandler(){
	HAL_SPI_IRQHandler(hspix);
}
void SPI2_IRQHandler(){
	HAL_SPI_IRQHandler(hspix + 1);
}
void HAL_SPI_TxCpltCallback(SPI_HandleTypeDef *hspi){
	switch((unsigned int)hspi->Instance){
	case SPI1_BASE:
		spitx[0] = 1;
		break;
	case SPI2_BASE:
		spitx[1] = 1;
		break;
	default:
		break;
	}
}
void HAL_SPI_RxCpltCallback(SPI_HandleTypeDef *hspi){
	switch((unsigned int)hspi->Instance){
	case SPI1_BASE:
		spirx[0] = 1;
		break;
	case SPI2_BASE:
		spirx[1] = 1;
		break;
	default:
		break;
	}
}
void HAL_SPI_TxRxCpltCallback(SPI_HandleTypeDef *hspi){
	switch((unsigned int)hspi->Instance){
	case SPI1_BASE:
		spirxtx[0] = 1;
		break;
	case SPI2_BASE:
		spirxtx[1] = 1;
		break;
	default:
		break;
	}
}
void HAL_SPI_ErrorCallback(SPI_HandleTypeDef *hspi){
	switch((unsigned int)hspi->Instance){
	case SPI1_BASE:
		spitx[0] = 2;
		spirx[0] = 2;
		spirxtx[0] = 2;
		break;
	case SPI2_BASE:
		spitx[0] = 2;
		spirx[0] = 2;
		spirxtx[1] = 2;
		break;
	default:
		break;
	}
}
#pragma endregion