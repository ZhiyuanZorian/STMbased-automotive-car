#include "interrupt.h"
#include "delay.h"
#include "timpwm.h"
unsigned long long T1[2] = { 0 };
volatile char ready = 0;
void hcsr04_initall(){
    //echo:B14 trig:D8
    GPIO_InitTypeDef gpio;
    gpio.Mode = GPIO_MODE_IT_RISING_FALLING;
    gpio.Pin = GPIO_PIN_14;
    gpio.Pull = GPIO_PULLUP;
    gpio.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(GPIOB, &gpio);
    HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 1);
    HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);
    gpio.Mode = GPIO_MODE_OUTPUT_PP;
    gpio.Pin = GPIO_PIN_8;
    HAL_GPIO_Init(GPIOD, &gpio);
    HAL_GPIO_WritePin(GPIOD, GPIO_PIN_8, 0);
}
void hcsr04_pulse(char group){
    switch(group){
    case 0:
        if(ready){
            HAL_GPIO_WritePin(GPIOD, GPIO_PIN_8, 1);
            delay_us(10);
            HAL_GPIO_WritePin(GPIOD, GPIO_PIN_8, 0);
        }     
        break;
    default:
        break;
    }
}
float hcsr04_distance(char group){
    switch(group){
    case 0:
        if(ready){
            return 0.017f * (T1[1] - T1[0]);
        }
        break;
    default:
        break;
    }
    return -1.f;
}
void EXTI15_10_IRQHandler(){
    HAL_GPIO_EXTI_IRQHandler(GPIO_PIN_14);
}
void HAL_GPIO_EXTI_Callback(unsigned short pin){
    char ioval;
    switch(pin){
    case GPIO_PIN_14:
        ioval = HAL_GPIO_ReadPin(GPIOB, GPIO_PIN_14);
        if(ioval){
            ready = 0;
            T1[0] = tim3_gettime_us();
        }
        else{
            ready = 1;
            T1[1] = tim3_gettime_us();
        }
        break;
    default:
        break;
    }
}