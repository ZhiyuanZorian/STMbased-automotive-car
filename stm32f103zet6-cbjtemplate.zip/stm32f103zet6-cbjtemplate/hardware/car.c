#include "car.h"
#pragma region forward_declaration
/*
PIN mapping
MOTOR
front left f:D13
front left b:D11
front right f:E13
front right b:E15
back left f:D9
back left b:D10
back right f:E14
back right b:E12

BLACKLINE
left G4
middle G6
right G8

OBSTACLE
left G2
right E10

BRIGHTNESS G1

BRIGHTNESS G1

SPEED ROTOR LEFT:A12 RIGHT:A11
*/

#define GETBIT(x,b) (((x)>>(b))&1)
extern signed char frontleft_speedduty;
extern signed char frontright_speedduty;
extern signed char backleft_speedduty;
extern signed char backright_speedduty;
extern volatile unsigned int time_1ms, time_1s;//timeline
extern volatile unsigned char counter_1ms, counter_5ms;
extern volatile signed char speed_count;
extern char halfspeed;
char frontleft_speedio, frontright_speedio;
unsigned char frontleft_speedtmp, frontright_speedtmp, speedcounter_5ms;
volatile unsigned char frontleft_speed, frontright_speed, avgspeed;
#pragma endregion
#pragma region motor

void car_forward(){
    frontleft_speedduty = SPEED_DUTY;
    frontright_speedduty = SPEED_DUTY;
    backleft_speedduty = SPEED_DUTY;
    backright_speedduty = SPEED_DUTY;
    // frontleft_speedduty = 55;
    // frontright_speedduty = 55;
    // backleft_speedduty = 55;
    // backright_speedduty = 55;
}
void car_forward_fast(){
    frontleft_speedduty = 100;
    frontright_speedduty = 100;
    backleft_speedduty = 100;
    backright_speedduty = 100;
}
void car_forward_slow(){
    frontleft_speedduty = 19;
    frontright_speedduty = 19;
    backleft_speedduty = 19;
    backright_speedduty = 19;
}
void car_backward(){
    frontleft_speedduty = -SPEED_DUTY;
    frontright_speedduty = -SPEED_DUTY;
    backleft_speedduty = -SPEED_DUTY;
    backright_speedduty = -SPEED_DUTY;
}
void car_left(){
    frontleft_speedduty = 3;
    frontright_speedduty = SPEED_DUTY;
    // frontright_speedduty = 55;
    backleft_speedduty = 3;
    backright_speedduty = SPEED_DUTY;
    // backright_speedduty = 55;
}
void car_right(){
    frontleft_speedduty = SPEED_DUTY;
    frontright_speedduty = 3;
    backleft_speedduty = SPEED_DUTY;
    backright_speedduty = 3;
}
void car_stop(){
    frontleft_speedduty = 0;
    frontright_speedduty = 0;
    backleft_speedduty = 0;
    backright_speedduty = 0;
    motor_frontleft(STOP);
    motor_frontright(STOP);
    motor_backleft(STOP);
    motor_backright(STOP);
}
void car_move_1ms(){
    //front left
    if(frontleft_speedduty > 0){
        if(speed_count < frontleft_speedduty){
            motor_frontleft(FORWARD);
        }
        else{
            motor_frontleft(STOP);
        }
    }
    else if(frontleft_speedduty<0){
        if(speed_count < (-1)*(frontleft_speedduty)){
            motor_frontleft(BACKWARD);
        }
        else{
            motor_frontleft(STOP);
        }
    }
    //front right
    if(frontright_speedduty > 0){
        if(speed_count < frontright_speedduty){
            motor_frontright(FORWARD);
        }
        else{
            motor_frontright(STOP);
        }
    }
    else if(frontright_speedduty < 0){
        if(speed_count < (-1) * (frontright_speedduty)){
            motor_frontright(BACKWARD);
        }
        else{
            motor_frontright(STOP);
        }
    }


    //back left
    if(backleft_speedduty > 0){
        if(speed_count < backleft_speedduty){
            motor_backleft(FORWARD);
        }
        else{
            motor_backleft(STOP);
        }
    }
    else if(backleft_speedduty < 0){
        if(speed_count < (-1) * (backleft_speedduty)){
            motor_backleft(BACKWARD);
        }
        else{
            motor_backleft(STOP);
        }
    }
    //back right
    if(backright_speedduty > 0){
        if(speed_count < backright_speedduty){
            motor_backright(FORWARD);
        }
        else{
            motor_backright(STOP);
        }
    }
    else if(backright_speedduty < 0){
        if(speed_count < (-1) * (backright_speedduty)){
            motor_backright(BACKWARD);
        }
        else{
            motor_backright(STOP);
        }
    }
}
void motor_backright(movedirection dir){
    switch(dir){
    case FORWARD:
        HAL_GPIO_WritePin(GPIOE, GPIO_PIN_14, 1);
        HAL_GPIO_WritePin(GPIOE, GPIO_PIN_12, 0);
        break;
    case BACKWARD:
        HAL_GPIO_WritePin(GPIOE, GPIO_PIN_14, 0);
        HAL_GPIO_WritePin(GPIOE, GPIO_PIN_12, 1);
        break;
    default:
        HAL_GPIO_WritePin(GPIOE, GPIO_PIN_14 | GPIO_PIN_12, 0);
        break;
    }
}
void motor_backleft(movedirection dir){
    switch(dir){
    case FORWARD:
        HAL_GPIO_WritePin(GPIOD, GPIO_PIN_9, 1);
        HAL_GPIO_WritePin(GPIOD, GPIO_PIN_10, 0);
        break;
    case BACKWARD:
        HAL_GPIO_WritePin(GPIOD, GPIO_PIN_9, 0);
        HAL_GPIO_WritePin(GPIOD, GPIO_PIN_10, 1);
        break;
    default:
        HAL_GPIO_WritePin(GPIOD, GPIO_PIN_10 | GPIO_PIN_9, 0);
        break;
    }
}
void motor_frontright(movedirection dir){
    switch(dir){
    case FORWARD:
        HAL_GPIO_WritePin(GPIOE, GPIO_PIN_13, 1);
        HAL_GPIO_WritePin(GPIOE, GPIO_PIN_15, 0);
        break;
    case BACKWARD:
        HAL_GPIO_WritePin(GPIOE, GPIO_PIN_13, 0);
        HAL_GPIO_WritePin(GPIOE, GPIO_PIN_15, 1);
        break;
    default:
        HAL_GPIO_WritePin(GPIOE, GPIO_PIN_15 | GPIO_PIN_13, 0);
        break;
    }
}
void motor_frontleft(movedirection dir){
    switch(dir){
    case FORWARD:
        HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, 1);
        HAL_GPIO_WritePin(GPIOD, GPIO_PIN_11, 0);
        break;
    case BACKWARD:
        HAL_GPIO_WritePin(GPIOD, GPIO_PIN_13, 0);
        HAL_GPIO_WritePin(GPIOD, GPIO_PIN_11, 1);
        break;
    default:
        HAL_GPIO_WritePin(GPIOD, GPIO_PIN_11 | GPIO_PIN_13, 0);
        break;
    }
}
void motor_init(){
    GPIO_InitTypeDef gpio;
    gpio.Pin = GPIO_PIN_9 | GPIO_PIN_10 | GPIO_PIN_11 | GPIO_PIN_13;
    gpio.Pull = GPIO_PULLUP;
    gpio.Mode = GPIO_MODE_OUTPUT_PP;
    gpio.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(GPIOD, &gpio);
    gpio.Pin = GPIO_PIN_12 | GPIO_PIN_14 | GPIO_PIN_15 | GPIO_PIN_13;
    gpio.Pull = GPIO_PULLUP;
    gpio.Mode = GPIO_MODE_OUTPUT_PP;
    gpio.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(GPIOE, &gpio);
}
#pragma endregion
//blackline obstacle brightness
#pragma region input
/*
BLACKLINE
left G4
middle G6
right G8

OBSTACLE
left G2
right E10

BRIGHTNESS G1

SPEED ROTOR LEFT:A12 RIGHT:A11

ULTRASONIC TRIG:D8 ECHO:B14 
*/
void sensorinput_init(){
    GPIO_InitTypeDef gpio;
    gpio.Mode = GPIO_MODE_INPUT;
    gpio.Pull = GPIO_PULLUP;
    gpio.Speed = GPIO_SPEED_FREQ_HIGH;
    gpio.Pin = GPIO_PIN_4 | GPIO_PIN_6 | GPIO_PIN_8 | GPIO_PIN_2 | GPIO_PIN_1;
    HAL_GPIO_Init(GPIOG, &gpio);
    gpio.Pin = GPIO_PIN_2;
    HAL_GPIO_Init(GPIOE, &gpio);
    //speed
    gpio.Pin = GPIO_PIN_11 | GPIO_PIN_12;
    HAL_GPIO_Init(GPIOA, &gpio);
}
blacklinestatus readblackline(){

    //BLACKLINE
    // left G4
    // middle G6
    // right G8
    //unsigned int x = GPIOG->IDR;
    //HAL_GPIO_ReadPin(GPIOG, GPIO_PIN_2);
    //return (blacklinestatus)(GETBIT(x, 4) << 2) | (GETBIT(x, 6) << 1) | (GETBIT(x, 8));
    return (blacklinestatus)((HAL_GPIO_ReadPin(GPIOG, GPIO_PIN_4) << 2) | (HAL_GPIO_ReadPin(GPIOG, GPIO_PIN_6) << 1) | HAL_GPIO_ReadPin(GPIOG, GPIO_PIN_8));
}
char leftobstacle(){
    return HAL_GPIO_ReadPin(GPIOG, GPIO_PIN_2);
}
char rightobstacle(){
    return HAL_GPIO_ReadPin(GPIOE, GPIO_PIN_10);
}
char envbrightness(){
    return HAL_GPIO_ReadPin(GPIOG, GPIO_PIN_1);
}
void speedmeasure_clear(){
    speedcounter_5ms = 0;
    frontleft_speedtmp = 0;
    frontright_speedtmp = 0;
}
void speedmeasure(){
    char fl, fr;
    speedcounter_5ms++;
    fl = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_12);
    fr = HAL_GPIO_ReadPin(GPIOA, GPIO_PIN_11);
    if(fl != frontleft_speedio){
        frontleft_speedio = fl;
        frontleft_speedtmp++;
    }
    if(fr != frontright_speedio){
        frontright_speedio = fr;
        frontright_speedio++;
    }
    speedcounter_5ms++;
    if(speedcounter_5ms >= 25){
        speedcounter_5ms = 0;
        frontleft_speed = frontleft_speedtmp * 12;//mult 2x:500ms 6x fix
        frontright_speed = frontright_speedtmp * 12;
        frontleft_speed = (unsigned char)(0.5175f * (float)(frontleft_speed + 0.5));
        frontright_speed = (unsigned char)(0.5175f * (float)(frontright_speed + 0.5));
        avgspeed = (frontleft_speed + frontright_speed) / 2;
        speedmeasure_clear();
    }
}
#pragma endregion