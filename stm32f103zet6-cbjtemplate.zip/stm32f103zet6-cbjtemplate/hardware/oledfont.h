#ifndef OLEDFONT_H
#define OLEDFONT_H
extern const char F6x8[92][6];
extern const char F8X16[1520];
extern const char BMP2[1024];
extern const char BMP[1024];
#endif
