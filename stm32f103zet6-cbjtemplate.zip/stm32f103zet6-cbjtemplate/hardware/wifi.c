#include "wifi.h"
#include "common.h"
#include "usart.h"
#include "delay.h"

const char *pc_hotspot_ssid = "garbagecbj";
const char *pc_hotspot_pwd = "cbjnb666";

const char *wifista_ip = "192.168.137.1";
const char *wifista_port = "8086";


extern uartbuf uartrecv[3];
extern UART_HandleTypeDef huartx[3];
char wifisendbuf[256] = { 0 };
void wifi_sendback_response(char mode){
	if(uartrecv[WIFI_UARTINDEX].flag & 0x8000){//received data
		int len = uartrecv[WIFI_UARTINDEX].flag & 0x7fff;
		uart_senddata(WIFI_SENDBACK, uartrecv[WIFI_UARTINDEX].buffer, len);
		if(mode){
			uartrecv[WIFI_UARTINDEX].flag = 0;//clear status flag
		}
	}
}
char *wifi_checkcmd(char *str){
	char *res = 0;
	if(uartrecv[WIFI_UARTINDEX].flag & 0x8000){
		uartrecv[WIFI_UARTINDEX].buffer[(uartrecv[WIFI_UARTINDEX].flag & 0x7fff)] = 0;//end line
		res = strstr(uartrecv[WIFI_UARTINDEX].buffer, str);
	}
	return res;
}
char wifi_apstacheck(){
	//return 0:BAD 1:good
	if(wifi_quittrans())return 0;
	wifi_send("AT+CIPSTATUS", ":", 50, 1);
	if(wifi_checkcmd("+CIPSTATUS:0") && wifi_checkcmd("+CIPSTATUS:1") && wifi_checkcmd("+CIPSTATUS:2") && wifi_checkcmd("+CIPSTATUS:4")){
		return 0;
	}
	return 1;
}
char wifi_send(char *data, char *ack, unsigned short waittime, char newline){
	char res = 0;
	int len;
	len = strlen(data);
	uartrecv[WIFI_UARTINDEX].flag = 0;
	uart_senddata(WIFI_UARTINDEX, data, len);
	if(newline){
		uart_sendcrlf(WIFI_UARTINDEX);
	}
	if(ack && waittime){
		while(--waittime){
			delay_ms(10);
			if(uartrecv[WIFI_UARTINDEX].flag & 0x8000){//received
				if(wifi_checkcmd(ack)){
					len = uartrecv[WIFI_UARTINDEX].flag & 0x7fff;
					uart_senddata(WIFI_SENDBACK, "ackdata:\r\n", 10);
					uart_senddata(WIFI_SENDBACK, uartrecv[WIFI_UARTINDEX].buffer, len);
					uart_sendcrlf(WIFI_SENDBACK);
					break;
				}
				uartrecv[WIFI_UARTINDEX].flag = 0;
			}
		}
		if(!waittime)res = 1;
	}
	return res;
}
char wifi_quittrans(){
	//return 0:quit good 1:quit fail
	//USART_TypeDef *p = huartx[WIFI_UARTINDEX].Instance;
	//send 3x '+'
	//p->DR = '+';
	//while(!(p->SR & 0x40));
	//delay_ms(15);
	//p->DR = '+';
	//while(!(p->SR & 0x40));
	//delay_ms(15);
	//p->DR = '+';
	//while(!(p->SR & 0x40));
	uart_senddata(WIFI_UARTINDEX, "+++", 3);
	delay_ms(500);
	return wifi_send("AT", "OK", 20, 1);
}
char wifi_constacheck(){
	//return 0:BAD 1:good
	char *p;
	if(wifi_quittrans())return 0;
	wifi_send("AT+CIPSTATUS", ":", 50, 1);//send AT+CIPSTATUS command
	p = wifi_checkcmd("STATUS:");
	return *p;
}
void wifi_getwanip(char *ipbuf){
	char *p, *p1;
	if(wifi_send("AT+CIFSR", "OK", 50, 1)){
		*ipbuf = 0;
		return;
	}
	p = wifi_checkcmd("\"");
	p1 = strstr(p + 1, "\"");
	*p1 = 0;
	strcpy(ipbuf, p + 1);
}
void wifi_initsta(){
	char p[64] = { 0 };
	while(wifi_send("AT", "OK", 20, 1)){
		wifi_quittrans();
		wifi_send("AT+CIPMODE=0", "OK", 200, 1);
		wifi_send("AT+SAVETRANSLINK=0", "OK", 200, 1);
		delay_ms(800);
	}
	wifi_send("AT+CWMODE=1", "OK", 50, 1);
	wifi_send("AT+RST", "OK", 20, 1);
	delay_ms(4500);
	sprintf(p, "AT+CWJAP=\"%s\",\"%s\"", pc_hotspot_ssid, pc_hotspot_pwd);
	while(wifi_send(p, "WIFI GOT IP", 20, 1)){
		;
	}
	uartrecv[WIFI_UARTINDEX].flag = 0;
	while(wifi_send("AT+CIPMUX=0", "OK", 20, 1));
}
void wifi_enter_passthrough(char *ip, char *port){
	char p[64] = { 0 };

	sprintf(p, "AT+CIPSTART=\"TCP\",\"%s\",%s", ip, port);
	wifi_send(p, "OK", 200, 1);
	while(wifi_send("AT+CIPMODE=1", "OK", 200, 1));
	wifi_send("AT+CIPSEND", "OK", 20, 1);

}
void wifi_httpget(char *ip, char *port, char *url, char *query){
	int k;
	uartrecv[WIFI_UARTINDEX].flag = 0;
	if(query){
		k = snprintf(wifisendbuf, 255, "GET %s?%s HTTP/1.1\r\n", url, query);
	}
	else{
		k = snprintf(wifisendbuf, 255, "GET %s HTTP/1.1\r\n", url);
	}
	uart_senddata(WIFI_UARTINDEX, wifisendbuf, k);
	k = snprintf(wifisendbuf, 64, "Host: %s:%s\r\n", ip, port);
	uart_senddata(WIFI_UARTINDEX, wifisendbuf, k);
	//uart_senddata(WIFI_UARTINDEX, "Connection: close\r\n", 19);
	uart_senddata(WIFI_UARTINDEX, "User-Agent: cbjlaji\r\n", 21);
	uart_sendcrlf(WIFI_UARTINDEX);
}
void wifi_httppost(char *ip, char *port, char *url, char *query, char *form, unsigned int formlength){
	int k;
	uartrecv[WIFI_UARTINDEX].flag = 0;
	if(query){
		k = snprintf(wifisendbuf, 255, "POST %s?%s HTTP/1.1\r\n", url, query);
	}
	else{
		k = snprintf(wifisendbuf, 255, "POST %s HTTP/1.1\r\n", url);
	}
	uart_senddata(WIFI_UARTINDEX, wifisendbuf, k);
	k = snprintf(wifisendbuf, 64, "Host: %s:%s\r\n", ip, port);
	uart_senddata(WIFI_UARTINDEX, wifisendbuf, k);
	//uart_senddata(WIFI_UARTINDEX, "Connection: close\r\n", 19);
	uart_senddata(WIFI_UARTINDEX, "Content-Type: application/x-www-form-urlencoded\r\n", 49);
	uart_senddata(WIFI_UARTINDEX, "User-Agent: cbjlaji\r\n", 21);
	k = snprintf(wifisendbuf, 64, "Content-Length: %d\r\n", formlength);
	uart_senddata(WIFI_UARTINDEX, wifisendbuf, k);
	uart_sendcrlf(WIFI_UARTINDEX);
	uart_senddata(WIFI_UARTINDEX, form, formlength);
	uart_sendcrlf(WIFI_UARTINDEX);
}
void processresponse1(){
	if(uartrecv[WIFI_UARTINDEX].flag & 0x8000){
		char tmp[6] = { 0 },*p;
		unsigned int length = uartrecv[WIFI_UARTINDEX].flag & 0x7fff;
		uartrecv[WIFI_UARTINDEX].flag = 0;		
		p= strstr(uartrecv[WIFI_UARTINDEX].buffer, "Q:");
		if(p){
			strncpy(tmp, p + 2, 5);
			uart_senddata(0, "RESPONSE GOOD\r\n", 15);
			uart_senddata(0, tmp, 5);
			uart_sendcrlf(0);
		}
		else{
			uart_senddata(0, "RESPONSE ERROR!\r\n", 17);
		}
	}
	
}