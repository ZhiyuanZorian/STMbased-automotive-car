#include "common.h"
#include "delay.h"
#include "usart.h"
#include "timpwm.h"
#include "iicspi.h"
#include "oled.h"
#include "wifi.h"
#include "car.h"
#include "interrupt.h"
extern oled ospi1;
void clock_init(unsigned int pll){
	HAL_StatusTypeDef res = HAL_OK;
	RCC_OscInitTypeDef rccosc;
	RCC_ClkInitTypeDef rccclk;
	rccosc.OscillatorType = RCC_OSCILLATORTYPE_HSE;//8M Crystal Oscillator
	rccosc.HSEState = RCC_HSE_ON;
	rccosc.HSEPredivValue = RCC_HSE_PREDIV_DIV1;//HSE Prescaler
	rccosc.PLL.PLLState = RCC_PLL_ON;
	rccosc.PLL.PLLSource = RCC_PLLSOURCE_HSE;
	rccosc.PLL.PLLMUL = pll;
	res = HAL_RCC_OscConfig(&rccosc);
	if(res)for(;;);
	rccclk.ClockType = (RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2);
	rccclk.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
	rccclk.AHBCLKDivider = RCC_SYSCLK_DIV1;
	rccclk.APB1CLKDivider = RCC_HCLK_DIV2;
	rccclk.APB2CLKDivider = RCC_HCLK_DIV1;
	res = HAL_RCC_ClockConfig(&rccclk, FLASH_LATENCY_2);
	if(res)for(;;);
	__HAL_RCC_GPIOA_CLK_ENABLE();
	__HAL_RCC_GPIOB_CLK_ENABLE();
	__HAL_RCC_GPIOC_CLK_ENABLE();
	__HAL_RCC_GPIOD_CLK_ENABLE();
	__HAL_RCC_GPIOE_CLK_ENABLE();
	__HAL_RCC_GPIOF_CLK_ENABLE();
	__HAL_RCC_GPIOG_CLK_ENABLE();
	__HAL_RCC_AFIO_CLK_ENABLE();
	__HAL_AFIO_REMAP_SWJ_NOJTAG();
}
void init(){
	GPIO_InitTypeDef gpio;
	HAL_Init();
	clock_init(RCC_PLL_MUL9);
	delay_init(72);
	
	gpio.Pin = GPIO_PIN_13;

	gpio.Mode = GPIO_MODE_OUTPUT_PP;
	gpio.Speed = GPIO_SPEED_FREQ_HIGH;
	gpio.Pull = GPIO_PULLUP;
	HAL_GPIO_Init(GPIOC, &gpio);
	//LED B13 E11 G11 E0
	HAL_GPIO_Init(GPIOB, &gpio);
	gpio.Pin = GPIO_PIN_0 | GPIO_PIN_11;
	HAL_GPIO_Init(GPIOE, &gpio);
	gpio.Pin = GPIO_PIN_11;
	HAL_GPIO_Init(GPIOG, &gpio);
	uart1_init(115200);
	iic1_init();
	//iic_scan(0);
	//spi1_init();	
	motor_init();
	sensorinput_init();
	//uart3_init(115200);
	
	car_stop();
	// wifi_initsta();
	// if(wifi_constacheck()){
	// 	uart_senddata(0, "WIFI GOOD\r\n", 11);
	// 	wifi_enter_passthrough(wifista_ip, wifista_port);
	// }
	// else{
	// 	uart_senddata(0, "WIFI BAD!\r\n", 11);
	// }
	tim3_init(999, 71);
	hcsr04_initall();
}