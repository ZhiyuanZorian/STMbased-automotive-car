#include "common.h"
#include "delay.h"
#include "usart.h"
#include "timpwm.h"
#include "oled.h"
#include "wifi.h"
#include "car.h"
#include "interrupt.h"
void searchline();
void carmove();
signed char frontleft_speedduty;
signed char frontright_speedduty;
signed char backleft_speedduty;
signed char backright_speedduty;
char halfspeed = 0;
unsigned char counter_200ms = 0;
//timer variables
extern volatile unsigned int time_1s, time_1ms;//timeline
extern volatile unsigned char counter_1ms, counter_5ms;
extern volatile signed char speed_count;
extern volatile unsigned char frontleft_speed, frontright_speed, avgspeed;
char wifidata[128] = { 0 };
oled ospi1;
volatile char prevcmd = COMM_STOP, currcmd, moveflag = 1;
volatile blacklinestatus black;
volatile float dist;
void searchline(){
	black = readblackline();
	switch(black){
	case BBB:
		//moveflag = 0;
		currcmd = COMM_STOP;
		break;
	case WBW:
		currcmd = COMM_UP;
		break;
	case BWW:
	case BBW:
		currcmd = COMM_LEFT;
		break;
	case WWB:
	case WBB:
	case WWW:
		currcmd = COMM_RIGHT;
		break;
	case BWB:
		break;
	}
}
void searchline_withbarrier(){
	float tmp;
	hcsr04_pulse(0);
	tmp = hcsr04_distance(0);
	if(tmp >= 0.){
		dist = tmp;
	}
	black = readblackline();
	if(dist >= 40.0f){
		switch(black){
		case BBB:
			//moveflag = 0;
			currcmd = COMM_STOP;
			break;
		case WBW:
			currcmd = COMM_UP;
			break;
		case BWW:
		case BBW:
			currcmd = COMM_LEFT;
			break;
		case WWB:
		case WBB:
		case WWW:
			currcmd = COMM_RIGHT;
			break;
		case BWB:
			break;
		}
	}
	else if(dist >= 15.1f){
		switch(black){
		case BBB:
			//moveflag = 0;
			currcmd = COMM_STOP;
			break;
		case WBW:
			currcmd = COMM_UP2;
			break;
		case BWW:
		case BBW:
			currcmd = COMM_LEFT;
			break;
		case WWB:
		case WBB:
		case WWW:
			currcmd = COMM_RIGHT;
			break;
		case BWB:
			break;
		}
	}
	else{
		currcmd = COMM_STOP;
	}

}
void carmove(){
	// if((leftobstacle() && rightobstacle())){
	// 	car_stop();
	// }
	// else{
		if(prevcmd != currcmd){
			prevcmd = currcmd;
			switch(currcmd){
			case COMM_UP:
				car_forward();
				break;
			case COMM_UP2:
				car_forward_slow();
				break;
			case COMM_DOWN:
				car_backward();
				break;
			case COMM_LEFT:
				car_left();
				break;
			case COMM_RIGHT:
				car_right();
				break;
			case COMM_STOP:
				car_stop();
				break;
			default:
				break;
			}
		}
	// }
	delay_ms(2);
}
int main(){
	
	int n;
	char buffer[32] = { 0 };
	init();
	float f;
	for(;;){
		if(counter_5ms >= 5){
			counter_5ms = 0;
			counter_200ms++;
			if(counter_200ms >= 10){
				 counter_200ms=0;
				// n = snprintf(wifidata, 127, "cbj:%d,%d\r\n", black, avgspeed);
				// uart_senddata(2, wifidata, n);
			}
			//LED B13 E11 G11 E0
			if(envbrightness()){//open light
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_13, 1);
				HAL_GPIO_WritePin(GPIOE, GPIO_PIN_11, 1);
				HAL_GPIO_WritePin(GPIOG, GPIO_PIN_11, 1);
				HAL_GPIO_WritePin(GPIOE, GPIO_PIN_0, 1);
			}
			else{//close light
				HAL_GPIO_WritePin(GPIOB, GPIO_PIN_13, 0);
				HAL_GPIO_WritePin(GPIOE, GPIO_PIN_11, 0);
				HAL_GPIO_WritePin(GPIOG, GPIO_PIN_11, 0);
				HAL_GPIO_WritePin(GPIOE, GPIO_PIN_0, 0);
			}
			searchline_withbarrier();
			carmove();
			//hcsr04_pulse(0);
			//delay_ms(100);
			//f = hcsr04_distance(0);
		}
		speedmeasure();
	}
}
